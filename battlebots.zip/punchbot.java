 class PunchBot{
  int botHealth = (int)(Math.random()*10+1);
  int botAttack = (int)(Math.random()*4+1);

}