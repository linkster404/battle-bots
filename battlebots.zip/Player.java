class Player{
  int playerHealth = (int)(Math.random()*10+1);
  int playerAttack = (int)(Math.random()*3+1);
}