class Slashbot{
    int botHealth = (int)(Math.random()*15+1);
    int botAttack = (int)(Math.random()*6+1);
}